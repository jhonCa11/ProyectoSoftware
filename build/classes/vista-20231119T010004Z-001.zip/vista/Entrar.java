
package vista;

import modelo.*;

public class Entrar {

    public Entrar(){
        
   }

    
    
}